CREATE SCHEMA `S-T`;
USE `S-T`;


CREATE TABLE Student
    (Sno              CHAR(9) PRIMARY KEY,
     Sname            CHAR(20) UNIQUE,
     Ssex             CHAR(2),
     Sage             SMALLINT,
     Sdept            CHAR(20)
    );
    
INSERT INTO Student (Sno, Sname, Ssex, Sage, Sdept)
VALUES ('S001', 'John Doe', 'M', 20, 'Computer Science'),
       ('S002', 'Jane Smith', 'F', 22, 'Engineering'),
       ('S003', 'Michael Johnson', 'M', 21, 'Mathematics');



CREATE TABLE Course
    (Cno              CHAR(4) PRIMARY KEY,
     Cname            CHAR(40),
     Cpno             CHAR(4),
     Ccredit          SMALLINT,
     FOREIGN KEY (Cpno) REFERENCES Course(Cno)
    );

INSERT INTO Course (Cno, Cname, Cpno, Ccredit)
VALUES ('C004', 'Math', NULL, 3),
	   ('C002', 'Engliah', NULL, 3),
       ('C005', 'Phys', NULL, 3);

DROP TABLE SC;
CREATE TABLE SC
    (Sno              CHAR(9),
     Cno              CHAR(4),
     Grade            SMALLINT,
     PRIMARY KEY (Sno, Cno),
     FOREIGN KEY (Sno) REFERENCES Student(Sno),
     FOREIGN KEY (Cno) REFERENCES Course(Cno)
    );


INSERT INTO SC (Sno, Cno, Grade)
VALUES ('S001', 'C002', 81),
       ('S002', 'C002', 86), 
       ('S002', 'C004', 90), 
       ('S003', 'C002', 86), 
       ('S003', 'C004', 100), 
       ('S003', 'C005', 81);


-- 1
SELECT DISTINCT Sname
FROM Student
WHERE NOT EXISTS (
    SELECT *
    FROM SC
    WHERE SC.Sno = Student.Sno AND SC.Grade <= 85
);

    
  -- 2  
SELECT Sname
FROM Student
JOIN SC ON Student.Sno = SC.Sno
GROUP BY Student.Sno, Sname
HAVING MIN(Grade) > 85;

