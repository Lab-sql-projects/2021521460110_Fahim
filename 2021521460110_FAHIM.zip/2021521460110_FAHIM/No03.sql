CREATE DATABASE No03;
use No03;


CREATE TABLE Teacher (
    Tno INT PRIMARY KEY,
    Tname VARCHAR(50)
);

INSERT INTO Teacher (Tno, Tname) VALUES
(1, 'John Doe'),
(2, 'Jane Smith'),
(3, 'Michael Johnson'),
(4, 'Emily Brown'),
(5, 'Daniel Wilson');


CREATE TABLE Student (
    Sno INT PRIMARY KEY,
    Sname VARCHAR(50),
    Sage INT,
    Ssex VARCHAR(1)
);


INSERT INTO Student (Sno, Sname, Sage, Ssex) VALUES
(95001, 'Michael', 18, 'M'),
(95002, 'Sarah', 19, 'F'),
(95003, 'Alex', 20, 'M'),
(95004, 'Jessica', 21, 'F'),
(95005, 'Ryan', 22, 'M'),
(95006, 'Emily', 20, 'F'),
(95007, 'Jacob', 19, 'M'),
(95008, 'Olivia', 18, 'F'),
(95009, 'Matthew', 21, 'M');


CREATE TABLE Course (
    Cno INT PRIMARY KEY,
    Cname VARCHAR(50),
    Tno INT,
    FOREIGN KEY (Tno) REFERENCES Teacher(Tno)
);

INSERT INTO Course (Cno, Cname, Tno) VALUES
(1001, 'Mathematics', 1),
(1002, 'Physics', 2),
(1003, 'History', 3),
(1004, 'Chemistry', 2),
(1005, 'Biology', 4);


CREATE TABLE SC (
    Sno INT,
    Cno INT,
    Score DECIMAL(5,2),
    PRIMARY KEY (Sno, Cno),
    FOREIGN KEY (Sno) REFERENCES Student(Sno),
    FOREIGN KEY (Cno) REFERENCES Course(Cno)
);


INSERT INTO SC (Sno, Cno, Score) VALUES
(95001, 1003, 79.5),
(95002, 1001, 88.0),
(95003, 1002, 95.2),
(95004, 1001, 82.7),
(95005, 1004, 90.0),
(95006, 1003, 87.2),
(95007, 1001, 91.5),
(95008, 1005, 85.0),
(95009, 1002, 78.8);



-- Query No 01 = The list of student names, who at least registers one common course with student with Sno “95005”
SELECT DISTINCT S.Sname
FROM Student S
JOIN SC SC1 ON S.Sno = SC1.Sno
JOIN SC SC2 ON SC1.Cno = SC2.Cno
WHERE SC2.Sno = 95005;


-- Query No 02 = To get the complete list of students, who registers only one course. Print their student numbers and names and order the list by student number.

SELECT S.Sno, S.Sname
FROM Student S
JOIN (
    SELECT Sno
    FROM SC
    GROUP BY Sno
    HAVING COUNT(DISTINCT Cno) = 1
) AS SingleCourseStudents ON S.Sno = SingleCourseStudents.Sno
ORDER BY S.Sno;

-- Query No 03 = The list of courses, each of which is registered by every student.

-- 1
SELECT C.Cno, C.Cname
FROM Course C
LEFT JOIN SC ON C.Cno = SC.Cno
GROUP BY C.Cno, C.Cname
HAVING COUNT(DISTINCT SC.Sno) = (SELECT COUNT(*) FROM Student);


-- 2
SELECT C.Cno, C.Cname
FROM Course C
WHERE NOT EXISTS (
    SELECT *
    FROM Student S
    WHERE NOT EXISTS (
        SELECT *
        FROM SC
        WHERE SC.Sno = S.Sno AND SC.Cno = C.Cno
    )
);


SELECT S.Sno, S.Sname
FROM Student S
JOIN (
    SELECT Sno
    FROM SC
    GROUP BY Sno
    HAVING COUNT(DISTINCT Cno) = 1
) AS SingleCourseStudents ON S.Sno = SingleCourseStudents.Sno
ORDER BY S.Sno
LIMIT 10;




SELECT C.Cno, C.Cname
FROM Course C
LEFT JOIN SC ON C.Cno = SC.Cno
GROUP BY C.Cno, C.Cname
HAVING COUNT(DISTINCT SC.Sno) = (SELECT COUNT(*) FROM Student)
ORDER BY C.Cno
LIMIT 3;





