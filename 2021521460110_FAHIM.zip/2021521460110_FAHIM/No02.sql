create database SC;
use SC;

-- Create the SC table
CREATE TABLE SC (
    SerialNumber INT PRIMARY KEY,
    Sno CHAR(10),
    Sname VARCHAR(50),
    Cno CHAR(10),
    Cname VARCHAR(50),
    Score INT
);

-- Insert the provided data
INSERT INTO SC (SerialNumber, Sno, Sname, Cno, Cname, Score)
VALUES
(1, '2005001', 'Mike', '0001', 'Math', 99),
(2, '2005002', 'John', '0001', 'Math', 89),
(3, '2005001', 'Mike', '0001', 'Math', 99),
(4, '2005001', 'Mike', '0001', 'Math', 99),
(5, '2005001', 'Mike', '0001', 'Math', 99),
(6, '2005002', 'John', '0001', 'Math', 89),
(7, '2005001', 'Mike', '0001', 'Math', 99),
(8, '2005002', 'John', '0001', 'Math', 89);

-- Delete redundant records based on attributes except for Serial number
DELETE FROM SC
WHERE SerialNumber NOT IN (
    SELECT SerialNumber
    FROM (
        SELECT SerialNumber,
               ROW_NUMBER() OVER (PARTITION BY Sno, Sname, Cno, Cname, Score ORDER BY SerialNumber) AS rn
        FROM SC
    ) AS temp
    WHERE rn = 1
); 

-- Delete redundant records based on attributes except for Serial number

DELETE FROM SC
WHERE EXISTS (
    SELECT *
    FROM SC AS SC2
    WHERE SC.SerialNumber > SC2.SerialNumber
      AND SC.Sno = SC2.Sno
      AND SC.Sname = SC2.Sname
      AND SC.Cno = SC2.Cno
      AND SC.Cname = SC2.Cname
      AND SC.Score = SC2.Score
);



        

